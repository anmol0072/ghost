import React, { useState, useEffect } from "react";
import { Code, Briefcase, Heart, Coffee, Github, Linkedin, Twitter, Mail, ChevronDown } from "lucide-react";

function About() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeTab, setActiveTab] = useState("journey");
  const [hoveredSkill, setHoveredSkill] = useState(null);

  // Animation on component mount
  useEffect(() => {
    setIsVisible(true);
  }, []);

  // Typing animation for the tagline
  const TypingEffect = ({ text }) => {
    const [displayText, setDisplayText] = useState("");
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
      if (currentIndex < text.length) {
        const timeout = setTimeout(() => {
          setDisplayText(prevText => prevText + text[currentIndex]);
          setCurrentIndex(prevIndex => prevIndex + 1);
        }, 100);
        return () => clearTimeout(timeout);
      }
    }, [currentIndex, text]);

    return <span>{displayText}</span>;
  };

  // Skills with progress bars
  const skills = [
    { name: "React", level: 90, color: "bg-blue-500" },
    { name: "Node.js", level: 85, color: "bg-green-500" },
    { name: "JavaScript", level: 95, color: "bg-yellow-500" },
    { name: "CSS/Tailwind", level: 80, color: "bg-purple-500" },
    { name: "UI/UX Design", level: 75, color: "bg-pink-500" },
    { name: "MongoDB", level: 70, color: "bg-teal-500" },
  ];

  // Timeline data
  const timeline = [
    {
      year: "2023",
      title: "Started Full Stack Development Journey",
      description: "Began exploring the world of web development with a focus on modern technologies."
    },
    {
      year: "2024",
      title: "First Major Project",
      description: "Created my first complete web application using React and Node.js."
    },
    {
      year: "2025",
      title: "Continuing Growth",
      description: "Expanding my skills in cloud technologies and advanced frontend frameworks."
    }
  ];

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section with Animation */}
        <div 
          className={`text-center space-y-10 mb-20 transform transition-all duration-1000 ${
            isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
          }`}
        >
          <h1 className="text-6xl font-bold leading-tight bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent">
            Hi, I'm Anmoldeep Singh
          </h1>
          <div className="h-1 w-32 bg-gradient-to-r from-indigo-600 to-pink-500 mx-auto rounded-full"></div>
          <p className="text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed font-light">
            <TypingEffect text="I'm a passionate Full Stack Developer transforming ideas into elegant digital solutions." />
          </p>
          
          <div className="flex justify-center space-x-6 pt-6">
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Github size={24} />
            </a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Twitter size={24} />
            </a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Mail size={24} />
            </a>
          </div>
          
          <div className="flex justify-center mt-10">
            <a 
              href="#profile" 
              className="flex items-center animate-bounce"
              aria-label="Scroll down"
            >
              <ChevronDown className="text-indigo-600" size={40} />
            </a>
          </div>
        </div>

        {/* Profile Image with Interactive Elements */}
        <div id="profile" className="flex flex-col md:flex-row items-center justify-center gap-10 mb-24">
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 rounded-full blur-lg opacity-25 group-hover:opacity-100 transition-opacity duration-300"></div>
            <img
              src="https://wallpapers.com/images/hd/cool-xbox-profile-pictures-9dtcc745il694rjs.jpg"
              alt="Profile"
              className="rounded-full relative z-10 border-4 border-white w-64 h-64 object-cover shadow-xl group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 shadow-lg z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <Coffee size={24} className="text-purple-600" />
            </div>
          </div>
          
          <div className="max-w-lg">
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent mb-4">
                "This photo just relates with being a programmer 
                and waking up after doing DSA"
              </h2>
              <p className="text-gray-600">
                When not coding, you'll find me exploring new tech, contributing to open source, 
                or enjoying a good cup of coffee.
              </p>
            </div>
          </div>
        </div>

        {/* Interactive Tabs Section */}
        <div className="bg-white p-8 rounded-xl shadow-xl mb-16">
          <div className="flex justify-center mb-8 border-b overflow-x-auto">
            <button
              onClick={() => setActiveTab("journey")}
              className={`px-6 py-3 font-medium text-lg transition-all ${
                activeTab === "journey"
                  ? "text-indigo-600 border-b-2 border-indigo-600"
                  : "text-gray-500 hover:text-gray-800"
              }`}
            >
              <Briefcase className="inline-block mr-2" size={18} />
              My Journey
            </button>
            <button
              onClick={() => setActiveTab("skills")}
              className={`px-6 py-3 font-medium text-lg transition-all ${
                activeTab === "skills"
                  ? "text-indigo-600 border-b-2 border-indigo-600"
                  : "text-gray-500 hover:text-gray-800"
              }`}
            >
              <Code className="inline-block mr-2" size={18} />
              Skills
            </button>
            <button
              onClick={() => setActiveTab("interests")}
              className={`px-6 py-3 font-medium text-lg transition-all ${
                activeTab === "interests"
                  ? "text-indigo-600 border-b-2 border-indigo-600"
                  : "text-gray-500 hover:text-gray-800"
              }`}
            >
              <Heart className="inline-block mr-2" size={18} />
              Interests
            </button>
          </div>

          {/* Journey Content */}
          <div className={`transition-opacity duration-500 ${activeTab === "journey" ? "opacity-100" : "opacity-0 hidden"}`}>
            <h2 className="text-3xl font-bold text-purple-800 mb-6 text-center">
              Professional Journey
            </h2>
            
            <div className="space-y-6 text-left max-w-4xl mx-auto mb-8">
              <p className="text-lg text-gray-600">
                I am a fresher in the field of full stack web development and this is a basic project from me. 
                My expertise spans across the entire web development stack, from crafting pixel-perfect UIs to 
                architecting scalable backend systems.
              </p>
              <p className="text-lg text-gray-600">
                Currently, I'm focused on building modern web applications using
                React, Node.js, and cloud technologies. I'm passionate about
                creating solutions that not only look great but also perform
                exceptionally well.
              </p>
            </div>
            
            {/* Timeline */}
            <div className="max-w-3xl mx-auto mt-12">
              <div className="relative">
                {/* Vertical line */}
                <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-indigo-200"></div>
                
                {/* Timeline items */}
                {timeline.map((item, index) => (
                  <div key={index} className="relative mb-12">
                    <div className={`flex items-center justify-${index % 2 === 0 ? "end" : "start"} w-1/2 ${index % 2 === 0 ? "ml-auto pr-8" : "mr-auto pl-8"}`}>
                      <div 
                        className="bg-white p-6 rounded-lg shadow-lg border-l-4 border-indigo-500 hover:shadow-xl transition-shadow duration-300"
                        style={{width: "calc(100% - 20px)"}}
                      >
                        <div className="absolute top-1/2 transform -translate-y-1/2 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-indigo-600 z-10"></div>
                        <span className="font-bold text-indigo-600">{item.year}</span>
                        <h3 className="text-xl font-semibold mt-1">{item.title}</h3>
                        <p className="text-gray-600 mt-2">{item.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Skills Content */}
          <div className={`transition-opacity duration-500 ${activeTab === "skills" ? "opacity-100" : "opacity-0 hidden"}`}>
            <h2 className="text-3xl font-bold text-purple-800 mb-10 text-center">
              Technical Skills
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {skills.map((skill, index) => (
                <div 
                  key={index} 
                  className="relative"
                  onMouseEnter={() => setHoveredSkill(index)}
                  onMouseLeave={() => setHoveredSkill(null)}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-gray-700">{skill.name}</span>
                    <span className="text-indigo-600 font-bold">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                    <div 
                      className={`${skill.color} h-full rounded-full transition-all duration-1000 ease-out`} 
                      style={{ 
                        width: hoveredSkill === index ? `${skill.level}%` : "0%", 
                        transform: hoveredSkill === index ? 'translateX(0)' : 'translateX(-100%)'
                      }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <div className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-t-4 border-indigo-500">
                <h3 className="text-2xl text-indigo-600 font-semibold mb-4">
                  Frontend Development
                </h3>
                <p className="text-lg text-gray-600">
                  Creating beautiful and responsive user interfaces with React,
                  Vue.js, and modern CSS frameworks
                </p>
              </div>
              <div className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-t-4 border-purple-500">
                <h3 className="text-2xl text-purple-600 font-semibold mb-4">
                  Backend Development
                </h3>
                <p className="text-lg text-gray-600">
                  Building robust and scalable server solutions with Node.js,
                  Python, and cloud services
                </p>
              </div>
              <div className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-t-4 border-teal-500">
                <h3 className="text-2xl text-teal-600 font-semibold mb-4">
                  UI/UX Design
                </h3>
                <p className="text-lg text-gray-600">
                  Designing intuitive and engaging user experiences with a focus on
                  accessibility and performance
                </p>
              </div>
            </div>
          </div>

          {/* Interests Content */}
          <div className={`transition-opacity duration-500 ${activeTab === "interests" ? "opacity-100" : "opacity-0 hidden"}`}>
            <h2 className="text-3xl font-bold text-purple-800 mb-10 text-center">
              Beyond Coding
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 text-left max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-xl shadow-lg group hover:bg-indigo-50 transition-all duration-300">
                <h3 className="text-2xl text-indigo-600 font-semibold mb-4 group-hover:translate-x-2 transition-transform duration-300">
                  Open Source Contributor
                </h3>
                <p className="text-lg text-gray-600">
                  Active contributor to various open-source projects, focusing on
                  developer tools and web frameworks
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-lg group hover:bg-purple-50 transition-all duration-300">
                <h3 className="text-2xl text-purple-600 font-semibold mb-4 group-hover:translate-x-2 transition-transform duration-300">
                  Tech Community
                </h3>
                <p className="text-lg text-gray-600">
                  Regular speaker at tech meetups and conferences, sharing
                  knowledge about web development
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-lg group hover:bg-teal-50 transition-all duration-300">
                <h3 className="text-2xl text-teal-600 font-semibold mb-4 group-hover:translate-x-2 transition-transform duration-300">
                  Mentorship
                </h3>
                <p className="text-lg text-gray-600">
                  Dedicated to mentoring junior developers and helping them grow
                  in their careers
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-lg group hover:bg-blue-50 transition-all duration-300">
                <h3 className="text-2xl text-blue-600 font-semibold mb-4 group-hover:translate-x-2 transition-transform duration-300">
                  Continuous Learning
                </h3>
                <p className="text-lg text-gray-600">
                  Always exploring new technologies and methodologies to stay at
                  the forefront of web development
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action with Hover Effects */}
        <div className="relative overflow-hidden rounded-2xl">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-teal-500 animate-gradient-x"></div>
          <div className="relative bg-gradient-to-r from-indigo-600/90 via-purple-600/90 to-teal-500/90 p-12 rounded-xl text-white text-center">
            <h2 className="text-4xl font-bold mb-6">Let's Work Together</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              I'm always open to discussing new projects, creative ideas, or
              opportunities to be part of your vision.
            </p>
            <div className="flex justify-center space-x-4">
              <a
                href="#contact"
                className="group relative inline-flex items-center justify-center overflow-hidden rounded-lg bg-white px-8 py-3 font-semibold text-lg text-indigo-600 shadow-inner transition-all duration-300"
              >
                <span className="absolute top-0 left-0 h-0 w-0 rounded-full bg-indigo-600 transition-all duration-500 ease-out group-hover:h-56 group-hover:w-56"></span>
                <span className="relative group-hover:text-white transition-colors duration-300">Get in Touch</span>
              </a>
              <a
                href="#projects"
                className="inline-block px-8 py-3 rounded-lg font-semibold text-lg border-2 border-white text-white hover:bg-white hover:text-indigo-600 transition-colors duration-300"
              >
                View Projects
              </a>
            </div>
          </div>
        </div>
        
        {/* Minimal Footer */}
        <div className="mt-16 text-center text-gray-500">
          <p>© {new Date().getFullYear()} Anmoldeep Singh • Built with React & Tailwind CSS</p>
        </div>
      </div>
    </div>
  );
}

export default About;