import React from "react";
import { X, Mail, Phone, Github, Linkedin } from "lucide-react";

export default function ContactPopup({ isOpen, onClose }) {
  // Replace these with your actual contact information
  const contactInfo = {
    email: "anmoldeep1408@gmail.com",
    whatsapp: "+91 7888710087",
    github: "https://github.com/anmol0072",
    linkedin: "https://linkedin.com/in/anmol0071"
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md relative overflow-hidden">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-indigo-400 via-purple-500 to-teal-500 p-4 text-white">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold">Contact Information</h3>
            <button
              onClick={onClose}
              className="text-white hover:text-teal-200 focus:outline-none transition-colors duration-200"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Contact information table */}
        <div className="p-6">
          <table className="w-full">
            <tbody>
              <tr className="border-b">
                <td className="py-4 pr-4">
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-purple-500 mr-2" />
                    <span className="font-medium">Email</span>
                  </div>
                </td>
                <td className="py-4">
                  <a 
                    href={`mailto:${contactInfo.email}`} 
                    className="text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    {contactInfo.email}
                  </a>
                </td>
              </tr>
              <tr className="border-b">
                <td className="py-4 pr-4">
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-green-500 mr-2" />
                    <span className="font-medium">WhatsApp</span>
                  </div>
                </td>
                <td className="py-4">
                  <a 
                    href={`https://wa.me/${contactInfo.whatsapp.replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-green-600 hover:text-green-800 transition-colors"
                  >
                    {contactInfo.whatsapp}
                  </a>
                </td>
              </tr>
              <tr className="border-b">
                <td className="py-4 pr-4">
                  <div className="flex items-center">
                    <Github className="h-5 w-5 text-gray-800 mr-2" />
                    <span className="font-medium">GitHub</span>
                  </div>
                </td>
                <td className="py-4">
                  <a 
                    href={contactInfo.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    {contactInfo.github.replace("https://github.com/", "")}
                  </a>
                </td>
              </tr>
              <tr>
                <td className="py-4 pr-4">
                  <div className="flex items-center">
                    <Linkedin className="h-5 w-5 text-blue-700 mr-2" />
                    <span className="font-medium">LinkedIn</span>
                  </div>
                </td>
                <td className="py-4">
                  <a 
                    href={contactInfo.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    {contactInfo.linkedin.replace("https://linkedin.com/in/", "")}
                  </a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 p-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded-md text-gray-800 font-medium transition-colors duration-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}