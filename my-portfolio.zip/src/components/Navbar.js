import { useState } from "react";
import { Menu, X } from "lucide-react";
import ContactPopup from "./contactpopup";

export default function Navbar() {
  const [isMenuOpen, setMenuOpen] = useState(false);
  const [isContactOpen, setContactOpen] = useState(false);

  // Function to handle smooth scrolling to sections with heading matches
  const scrollToSection = (headingText) => {
    // Find all heading elements
    const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    
    // Find the heading that contains the text we're looking for
    let targetSection = null;
    
    headings.forEach(heading => {
      if (heading.textContent.toLowerCase().includes(headingText.toLowerCase())) {
        // Use the closest section or div as the target
        targetSection = heading.closest('section') || heading.closest('div') || heading;
      }
    });
    
    // If we found a matching heading, scroll to it
    if (targetSection) {
      targetSection.scrollIntoView({ behavior: "smooth" });
      // Close mobile menu after clicking
      setMenuOpen(false);
    }
  };

  // Function to handle Get in Touch button click
  const handleGetInTouchClick = () => {
    // This function will find any "Get in Touch" link/button in the About section
    // and add a click event listener to it
    setTimeout(() => {
      const getInTouchElements = document.querySelectorAll('a, button');
      
      getInTouchElements.forEach(element => {
        if (element.textContent.toLowerCase().includes("get in touch")) {
          // Remove any existing listeners first to avoid duplicates
          element.removeEventListener('click', openContactPopup);
          // Add the new click listener
          element.addEventListener('click', openContactPopup);
          // Style it as a button if it's not already
          if (element.tagName.toLowerCase() === 'a') {
            element.style.cursor = 'pointer';
            if (!element.className.includes('btn') && !element.className.includes('button')) {
              element.className += " inline-block px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-md hover:from-indigo-600 hover:to-purple-600 transition-all duration-300";
            }
            // Prevent default to avoid navigation
            element.addEventListener('click', (e) => e.preventDefault());
          }
        }
      });
    }, 1000); // Give the page time to load
  };

  // Function to open the contact popup
  const openContactPopup = (e) => {
    e.preventDefault();
    setContactOpen(true);
  };

  // Execute once when component mounts
  useState(() => {
    handleGetInTouchClick();
  }, []);

  return (
    <>
      <nav className="w-full h-max bg-gradient-to-r from-indigo-400 via-purple-500 to-teal-500 shadow-lg fixed top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* logo and brand */}
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span className="text-2xl font-bold text-white bg-opacity-20 bg-white px-3 py-1 rounded-lg">
                  AS
                </span>
              </div>
              <div className="md:block hidden ml-4">
                <span className="text-white font-semibold text-lg">
                  Anmoldeep Singh
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <div className="hidden md:block">
              <ul className="flex space-x-8">
                <li>
                  <button
                    onClick={() => {
                      scrollToSection("professional journey");
                      handleGetInTouchClick(); // Re-attach event listeners when navigating to About
                    }}
                    className="text-white hover:text-teal-200 px-3 py-2 rounded-md text-sm font-medium cursor-pointer"
                  >
                    About
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("my skills")}
                    className="text-white hover:text-teal-200 px-3 py-2 rounded-md text-sm font-medium cursor-pointer"
                  >
                    Skills
                  </button>
                </li>
                
                <li>
                  <button
                    onClick={() => scrollToSection("my projects")}
                    className="text-white hover:text-teal-200 px-3 py-2 rounded-md text-sm font-medium cursor-pointer"
                  >
                    Projects
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("Get in touch")}
                    className="text-white hover:text-teal-200 px-3 py-2 rounded-md text-sm font-medium cursor-pointer"
                  >
                    Contact
                  </button>
                </li>
              </ul>
            </div>

            {/* Mobile navigation */}
            <div className="md:hidden">
              <button
                onClick={() => setMenuOpen(!isMenuOpen)}
                className="text-white hover:text-teal-200 focus:outline-none transition-color duration-200"
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-gradient-to-b from-indigo-600 to-purple-600">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <button
                onClick={() => {
                  scrollToSection("about");
                  handleGetInTouchClick(); // Re-attach event listeners when navigating to About
                  setMenuOpen(false);
                }}
                className="w-full text-left text-white hover:text-teal-400 block px-3 py-2 rounded-md transition-color duration-200 cursor-pointer"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("my skills")}
                className="w-full text-left text-white hover:text-teal-400 block px-3 py-2 rounded-md transition-color duration-200 cursor-pointer"
              >
                Skills
              </button>
              <button
                onClick={() => scrollToSection("tracer")}
                className="w-full text-left text-white hover:text-teal-400 block px-3 py-2 rounded-md transition-color duration-200 cursor-pointer"
              >
                Tracer
              </button>
              <button
                onClick={() => scrollToSection("my projects")}
                className="w-full text-left text-white hover:text-teal-400 block px-3 py-2 rounded-md transition-color duration-200 cursor-pointer"
              >
                Projects
              </button>
              <button
                onClick={() => scrollToSection("contact us")}
                className="w-full text-left text-white hover:text-teal-400 block px-3 py-2 rounded-md transition-color duration-200 cursor-pointer"
              >
                Contact
              </button>
            </div>
          </div>
        )}
      </nav>
      {/* Add a spacer to prevent content from hiding behind fixed navbar */}
      <div className="h-16"></div>

      {/* Contact Popup */}
      <ContactPopup 
        isOpen={isContactOpen} 
        onClose={() => setContactOpen(false)} 
      />
    </>
  );
}